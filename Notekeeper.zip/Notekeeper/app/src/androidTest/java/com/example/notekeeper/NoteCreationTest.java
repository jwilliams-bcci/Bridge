import junit.framework.TestCase;

public class NoteCreationTest extends TestCase {

}